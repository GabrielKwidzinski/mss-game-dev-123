"use strict";



{
	const scriptsInEvents = {



	};
	
	self.C3.ScriptsInEvents = scriptsInEvents;
}
